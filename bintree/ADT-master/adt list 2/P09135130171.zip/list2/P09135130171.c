//NIM/Nama : 13512017/Miftahul Mahfuzh
//Nama file : P09135130171.c
//Topik : List linier double pointer 
//Tanggal : 5 November 2014
//Deskripsi : List Linier berkait double pointer dengan first dan last
#include "list2.h"
/* ***************** PRIMITIF-PRIMITIF LIST ***************** */

/* *** TEST LIST KOSONG *** */

boolean IsListEmpty (List L) 
/* Mengirim true jika list kosong: First(L) = dummy@ dan Last(L) = dummy@ */
{ return (First(L) == Nil && Last(L) == Nil); }

/* *** PEMBUATAN LIST KOSONG *** */

void CreateList (List *L)
/* I.S. Sembarang */
/* F.S. Terbentuk list L kosong, dengan satu elemen dummy */
{
	First(*L) = Nil; 
	Last(*L) = Nil;
}

/* *** Manajemen Memori *** */

address Alokasi (infotype X)
/* Mengirimkan address hasil alokasi sebuah elemen */
/* Jika alokasi berhasil, maka address tidak Nil, dan misalnya menghasilkan P, maka
Info(P) = X, Next(P) = Nil */
/* Jika alokasi gagal, mengirimkan Nil */
{
	address P;
	P = (address)malloc(sizeof(infotype));
	if (P != Nil)
	{
		Info(P) = X;
		Next(P) = Nil;
		Prev(P) = Nil;
	}
	return P;
}
void Dealokasi (address *P)
/* I.S. P terdefinisi */
/* F.S. P dikembalikan ke sistem */
/* Melakukan dealokasi/pengembalian address P */
{	free(*P);}

/* *** PENCARIAN SEBUAH ELEMEN LIST *** */

boolean FSearch (List L,address P)
/* Mencari apakah ada elemen list yang beralamat P */
/* Mengirimkan true jika ada, false jika tidak ada */
{
  address Pl;
  boolean ada = false;
  /*algoritma*/
  Pl = First(L);
  while(Pl != Nil && !ada)
  {
  	if (Pl == P) ada = true;
  	else Pl = Next(Pl);
  }
  return ada;
}

address Search (List L,infotype X) 
/* Mencari apakah ada elemen list dengan Info(P) = X */
/* Jika ada, mengirimkan address elemen tersebut */
/* Jika tidak ada, mengirimkan Nil */
{
	address P;
	/*algoritma*/
	P = First(L);
	while(P != Nil && Info(P) != X)
		P = Next(P);
	return P;
}

/* ***************** PRIMITIF BERDASARKAN NILAI ******************/

/* *** PENAMBAHAN ELEMEN *** */

void InsVFirst (List *L,infotype X)
/* I.S. L mungkin kosong */
/* F.S. Melakukan alokasi sebuah elemen dan menambahkan elemen pertama dengan nilai
X jika alokasi berhasil */
{ 
	/* Kamus Lokal */
	address last,P;
	/* Algoritma */
	P = Alokasi(X);
	InsertFirst(L,P);
}



void InsVLast (List *L,infotype X)
/* I.S. L mungkin kosong */
/* F.S. Melakukan alokasi sebuah elemen dan menambahkan elemen list di sebelum
elemen akhir (elemen sebelum elemen dummy) bernilai X
jika alokasi berhasil. */
/*Jika alokasi gagal: I.S. = F.S. */
{
	/*kamus lokal*/
	address P,Pl;
	/*algoritma*/
	P = Alokasi(X);
	if (P != Nil) InsertLast(L,P);
}

/* *** PENGHAPUSAN ELEMEN *** */

void DelVFirst (List *L,infotype *X)
/* I.S. List L tidak kosong */
/* F.S. Elemen pertama list dihapus. nilai info disimpan pada X */
/*dan alamat elemen pertama didealokasi */
{
	address P;
	/*algoritma*/
	P = First(*L);
	(*X) = Info(P);
	First(*L) = Next(P);
}

void DelVLast (List *L,infotype *X)
/* I.S. List tidak kosong */
/* F.S. Elemen sebelum dummy dihapus nilai info disimpan pada X */
/*dan alamat elemen terakhir sebelum dummy di-dealokasi */
{
	address P;
	/*algoritma*/
	P = Last(*L);
	if(P == First(*L)) 
	{
		Last(*L) = Nil;
		First(*L) = Nil;
	}
	else
	{
		Last(*L) = Prev(P);
		Next(Last(*L)) = First(*L);
	}
	(*X) = Info(P);
	Dealokasi(&P);
}


/* ***************** PRIMITIF BERDASARKAN ALAMAT ***************** */

/* *** PENAMBAHAN ELEMEN BERDASARKAN ALAMAT *** */

void InsertFirst (List *L,address P)
/* I.S. Sembarang, P sudah dialokasi */
/* F.S. Menambahkan elemen ber-address P sebagai elemen pertama */
{ 
	/* Kamus Lokal */
	address last;
	/* Algoritma */
	if (IsListEmpty(*L)) Next(P) = P;
	else /* L tidak kosong */ 
	{
		last = First(*L);
		while (Next(last) != First(*L))
			last = Next(last);
		/* Next(last) = First(L) ==> elemen terakhir */
		Next(P) = First(*L);
		Next(last) = P;
	}
	First(*L) = P;
}

void InsertAfter (List *L,address P,address Prec)
/* I.S. Prec pastilah elemen list dan bukan elemen terakhir, */
/*P sudah dialokasi */
/* F.S. Insert P sebagai elemen sesudah elemen beralamat Prec */
{
	//Algoritma
	Next(P) = Next(Prec);
	Prev (Next(Prec)) = P;
	Next(Prec) = P;
	Prev (P) = Prec;	
}

void InsertLast (List *L,address P)
/* I.S. Sembarang, P sudah dialokasi */
/* F.S. P ditambahkan sebagai elemen terakhir yang baru, */
/*yaitu menjadi elemen sebelum dummy */
{
	//Kamus Lokal
	address Prec;
	//Algoritma
	if (IsListEmpty(*L)) {
		InsertFirst(L,P);
	}
	else {
		Prec = Prev(Last(*L));
		Next(P) = Nil;
		Next(Prec) = P;
		Prev (P) = Prec;
		Last(*L) = P;
	}
}


/* *** PENGHAPUSAN SEBUAH ELEMEN *** */

void DelFirst (List *L,address *P)
/* I.S. List tidak kosong */
/* F.S. P adalah alamat elemen pertama list sebelum penghapusan */
/*Elemen list berkurang satu (mungkin menjadi kosong) */
/* First element yg baru adalah suksesor elemen pertama yang lama */
{
	//Kamus Lokal
	
	//Algoritma
	(*P) = First(*L);
	if (First(*L) == Last(*L)) {
		First(*L) = Nil;
		Last(*L) = Nil;
	}
	else {
		First(*L) = Next(First(*L));
		Prev(First(*L)) = Nil;
		Next(*P) = Nil;
		Prev (*P) = Nil;
	}
}

void DelLast (List *L,address  *P)
/* I.S. List tidak kosong */
/* F.S. P adalah alamat elemen terakhir sebelum dummy pada list sebelum
penghapusan */
/*Elemen list berkurang satu (mungkin menjadi kosong) */
{ 
	(*P) = Last(*L);
	if (First(*L) == Last(*L)) { // 1 elemt
		First(*L) = Nil;
		Last(*L) = Nil;
	}
	else {
		Next(Prev(*P)) = Nil;
		Last(*L) = Prev(*P);
		Prev(*P) = Nil;
	}
}
void DelAfter ( List *L,address *Pdel,address Prec)
/* I.S. List tidak kosong. Prec adalah anggota list. */
/* F.S. Menghapus Next(Prec) Pdel adalah alamat elemen list yang dihapus */
{
	(*Pdel) = Next(Prec);
	Next(Prec) = Next(Next(Prec));
	Prev(Next(Prec)) = Prec;
	Next(*Pdel) = Nil;
	Prev(*Pdel) = Nil;
}
/* ***************** PROSES SEMUA ELEMEN LIST ***************** */

void PrintInfo (List L)
/* I.S. List mungkin kosong */
/* F.S. Jika list tidak kosong, */
/* Semua info yg disimpan pada elemen list (kecuali dummy) diprint */
/* Jika list kosong, hanya menuliskan "list kosong" */
{ 
	/* Kamus Lokal */
	address P;
	/* Algoritma */
	P = First(L);
	if (IsListEmpty(L)) printf("List Kosong \n"); 
	else if(Next(P) == P) printf("%d", Info(P));
	else 
	{
		P = First(L);
		do 
		{
			printf("%d, ", Info(P));
			P = Next(P);
		} while (Next(P) != First(L));
		printf("%d", Info(P));
	}	
}

/* ****************** TAMBAHAN ********************************** */
int NbElmt (List L)
/* Mengirimkan jumlah elemen list L; mengirimkan 0 jika list kosong */
{
	address P;
	int sum = 0;
	/*algoritma*/
	P = First(L);
	if(P != Nil)
	{
		while(P != First(L))
		{
			sum += 1;
			P = Next(P);
		}		
	} 
	return sum;
}
int NbX (infotype X,List L)
/* Mengirimkan jumlah kemunculan elemen bernilai X dalam list L; 
mengirimkan 0 jika list kosong */
{
	address P;
	int sum = 0;
	/*algoritma*/
	P = First(L);
	if(P != Nil)
	{
		if (Next(P) == P)
		{ if (Info(P) == X) sum += 1;}
		else 
		{
			while(Next(P) != First(L))
			{			
				if(Info(P) == X) sum += 1;
				P = Next(P);
			}		
		} 
		return sum;
	}
}

int Jarak (List L, infotype X,infotype Y)
/* Mengirimkan jarak (banyaknya elemen) antara elemen dengan info X 
dan elemen dengan info Y (tidak termasuk elemen X dan Y sendiri). 
Jika X dan Y tepat bersebelahan, jaraknya adalah 0. Jika ada lebih 
dari satu elemen X dan/atau Y di L maka digunakan elemen X dan Y 
yang pertama kali ditemukan. Urutan kemunculan X dan Y bebas, 
artinya X dapat muncul sebelum atau sesudah Y. */  /* Prekondisi : X 
dan Y pasti berbeda dan pasti ada di L, sehingga L tidak mungkin 
kosong. */
{
	address P,Px,Py;
	int sum = 0;
	/*algoritma*/
	Px = Search(L,X);
	Py = Search(L,Y);
	P = Next(Px);
	Py = Search(L,Y);
	while(P != Py)
		sum += 1;
	return sum;
}

void InverseList (List *L)
/* I.S. L terdefinisi, mungkin kosong */ /* F.S. Elemen list dibalik 
: Elemen terakhir menjadi elemen pertama, dan seterusnya */  
/*Membalik elemen list, tanpa melakukan alokasi/dealokasi */
{
	address P,prec;
	/*algoritma*/
	if (!IsListEmpty(*L))
	{
		if (!(Next(P) == P))
		{
			while(Next(P) != First(*L))
			{
				prec = Next(P);
				Next(P) = Prev(P);
				Prev(P) = prec;
				P = Next(P);
			}
		}
	}
}
void RemAllX (List *L,infotype X)
/*I.S. L terdefinisi, mungkin kosong */ /* F.S. Tidak ada elemen L 
yang bernilai X */ /* Menghapus seluruh elemen L yang bernilai X */
{
	address P,Pdel;
	/*algoritma*/
	if(!IsListEmpty(*L))
	{
		P = First(*L);
		while(Next(P) != First(*L))
		{		
			if(Info(P) == X)
				DelAfter(L,&Pdel,Prev(P));	
			P = Next(P);
		}
		if(Info(P) == X)
				DelAfter(L,&Pdel,Prev(P));			
	}
}
void SubList (List L1, int start,int count,int arah,List *L2);
/* I.S. L1, start, count, dan arah terdefinisi. start ≥ 1 count ≥ 1 
arah bernilai 1 atau ‐ 1. L2 sembarang. */ 
/* F.S. Jika arah = 1, maka L2 berisi elemen L1 dari elemen ke ‐ start 
hingga elemen ke ‐ (start+count ‐ 1) (sesuai urutan di L1). 
Jika arah = ‐ 1, maka L2 berisi elemen L1 dari elemen 
ke ‐ (start+count ‐ 1) hingga elemen ke ‐ start 
(dengan urutan terbalik dari urutan di L1). Setiap elemen L2 
harus dialokasi sebagai elemen baru. Jika ada elemen yang gagal 
dialokasi, maka L2 menjadi kosong dan
semua elemen yang sudah telanjur dia l okasi harus didealokasi. Jika 
start > jumlah elemen L1, L2 kosong. Jika start ≤ jumlah elemen L1 
dan (start+count ‐ 1) > jumlah elemen L1, L2 berisi (jumlah elemen L1 
– start + 1) elemen (kurang dari count). */
