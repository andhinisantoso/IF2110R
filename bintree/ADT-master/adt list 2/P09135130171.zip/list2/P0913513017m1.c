//NIM/Nama : 13512017/Miftahul Mahfuzh
//Nama file : P0913513017m1.c
//Topik : List linier double pointer 
//Tanggal : 5 November 2014
//Deskripsi : List Linier berkait double pointer dengan first dan last

#include "list2.h"

int main()
{
  List L;
  int X,Y;
  int start,count,arah;
  infotype nilai;
	CreateList(&L);
  printf("**Set List L**\n");
  printf("Masukkan nilai L : \n");
				do{
					scanf("%d",&nilai);
					if (nilai != -999)
						InsVLast(&L,nilai);
				} while (nilai != -999);
    if (IsListEmpty(L)) {
      printf ("List Kosong\n");
    }
    else 
    {
      printf("List L : [ ");
      PrintInfo(L);
      printf(" ]\n"); 
      do
      {
				scanf("%d %d",&X,&Y);    
				if (X == Y || Search(L,X) == Nil || Search(L,Y) == Nil )
				 printf("X dan Y harus berbeda dan merupakan elemen list\n");
			} while(!(X != Y && Search(L,X) != Nil && Search(L,Y) != Nil ));
			printf("jumlah kemunculan X dan Y dalam l adalah : %d & %d\n",NbX(X,L),NbX(Y,L));
			printf("jarak X dan Y : %d",Jarak(L,X,Y));
			do
			{
				printf("masukkan start, count, arah");			
				scanf("%d %d %d",&start,&count,&arah);			
				if(start >= 1 && count >= 1 && (arah == 1 || arah == -1)) break;
				else printf("masukan anda salah\n");
			}while(1);
			RemAllX(&L,X);
			printf("List L : [ ");
			PrintInfo(L);
			printf("]\n"); 
		}
	return 0;
}
