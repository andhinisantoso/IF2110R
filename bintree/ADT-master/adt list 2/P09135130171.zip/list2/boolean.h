#ifndef __boolean__
#define __boolean__
#define true 1
#define false 0
#define boolean unsigned char
#endif 
